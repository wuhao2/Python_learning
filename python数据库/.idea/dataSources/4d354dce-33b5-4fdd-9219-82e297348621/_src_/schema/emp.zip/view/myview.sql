CREATE VIEW `myview` AS
  SELECT
    `emp`.`emp`.`empno`    AS `empno`,
    `emp`.`emp`.`ename`    AS `ename`,
    `emp`.`emp`.`job`      AS `job`,
    `emp`.`emp`.`hiredate` AS `hiredate`,
    `emp`.`emp`.`sal`      AS `sal`,
    `emp`.`emp`.`comm`     AS `comm`,
    `emp`.`emp`.`deptno`   AS `deptno`,
    `emp`.`emp`.`grade`    AS `grade`
  FROM `emp`.`emp`
  WHERE (`emp`.`emp`.`deptno` = 3)